const cluster = require('cluster');
const axios = require('axios');
const os = require('os');
const logger = require('./utils/Logger.js');
const config = require('./utils/Configuration.js');



//inicia con argumentos tenant_id, apilayer (ejemplo http://localhost:8081), micorservicio (zipper, converter)
if(process.argv.length < 5) {
    logger.error("[INPUT][] Starting microservice error arguments");
    return;
}

const uservice = process.argv[4];
const tenant = process.argv[2];
logger.label(tenant + " " + uservice );

let ptask = null;
if(uservice == 'zipper') {
    ptask = require('.microservices/zipper/zipper.js');
}
else if(uservice == 'converter') {
    ptask = require('.microservices/converter/converter.js');
}
else if(uservice == 'uploader') {
    ptask = require('.microservices/uploader/uploader.js');
}
else if(uservice == 'input') {
    ptask = require('.microservices/input/input.js');
}
else if(uservice == 'verificator') {
    ptask = require('./microservices/verificator/verificator.js');
}
else {
    logger.error("[][] Starting microservice name error " + uservice);
    return;
}

async function getfiles(_files) {

    return new Promise( (resolve) => {
        _files.length = 0;
        axios.get(
            config.instance().getapilayer_url() + '/ingestor/v1/verify',
            {
                params: { body: JSON.stringify({tenant_id: config.instance().gettenant_id(), limit : 500}) },
                headers: { 'Content-Type': 'application/json' }
            }
        ).then((result) => {
            _files.push(...result.data.audios);
            resolve(_files.length);
        }).catch((e) => {
            logger.error("[PRIMARY][get newfiles] Error " + e);
            resolve(_files.length);
        })
    });
}


async function setstate(myfile_id, mystate, body = {}) {

    body.tenant_id = config.instance().gettenant_id()
    body.file_id = myfile_id
    body.state = mystate

	return new Promise( (resolve) => {
    		axios.patch(
        		config.instance().getapilayer_url() + '/ingestor/v1/'+ uservice +'/state',
        		JSON.stringify(body),
            		{
                		headers: { 'Content-Type': 'application/json' }
            		})
            		.then((result) => {
				resolve(true);
			})
			.catch((e) => {
                		logger.error("[PRIMARY][setstate] Error " + e);
				resolve(true)
            		});
	});

}


async function processorext(wrkr_id, files) {
    return ptask.performTask(wrkr_id, files);
}


config.instance().configure(tenant, process.argv[3]).then(() => {

    if (cluster.isPrimary) {
        logger.info(`[PRIMARY] process ${process.pid} is running`);

        const numWorkers = config.instance().getObject().microservices[uservice].number_of_workers ? config.instance().getObject().microservices[uservice].number_of_workers : 1;

        cluster.setupPrimary({windowsHide: true});

        var files = [];
        let filesDictionary = {}
        var workers_sleeping = 0;
        var fillfiles_timeid = null;
        var fillfiles_running = false;

        async function fillfiles(origin) {
            //TODO: Checkear getIsLastVersion() y si es falso process.exit()
            //si no están los workers creados o hay menos, los crea
            logger.info("[PRIMARY] ejecutando fillfiles("+ origin +")");
            if(fillfiles_running) {
                logger.info("[PRIMARY] fillfiles("+ origin +") return");
                return;
            }
            fillfiles_running = true;

            numWorkersactual = Object.values(cluster.workers).length;
            if(numWorkersactual < numWorkers) {
                for (let i = numWorkersactual; i < numWorkers; i++) {
                    cluster.fork();
                }
            }
            let number = 0
            number = await getfiles(files);

            logger.info("[PRIMARY] fillfiles("+ origin +") returning "+ number +"elements");
            if(number > 0) {
                workers_sleeping = 0;
                for (let worker of Object.values(cluster.workers)) {
                    worker.send({
                        cmd: "WAKEUP"
                    })
                }
            }
            else {
		        fillfiles_timeid = setTimeout(fillfiles, 5000);
                logger.info("[PRIMARY] No hay audios para reprocesar, reintenta en 5s timeid="+ fillfiles_timeid);
            }
            fillfiles_running = false;
        }

        cluster.on('exit', (worker, code, signal) => {
            console.log(`[${uservice}][PRIMARY] Worker process ${worker.id} died.`);
        });

        cluster.on('message', (worker, msg) => {
            if(msg.event == "READY") {
                if(files.length > 0) {  // TODO: Verifique getIsLastVersion()
                    const popArray = (array, num) => {
                        const newArray = []
                        for (let i = 0; i < num; i++) {
                            if (array.length > 0){
                                newArray.push(array.pop())
                            } else {
                                break
                            }
                        }
                        return newArray
                    }

                    const selectedFiles = popArray(files, 100)

                    worker.send({
                        cmd: "EAT",
                        files: selectedFiles
                    })
                }
                else {
                    worker.send({
                        cmd: "SLEEP"
                    })
                }
            }
            else if(msg.event == "SLEEPING") {
                workers_sleeping++;
                logger.info(`[PRIMARY] Worker process ${worker.id} is sleeping. Total worker sleeping: ${workers_sleeping}`);
                if(workers_sleeping == Object.values(cluster.workers).length) {
		            logger.info(`[PRIMARY] All Workers sleeping. Executing fillfiles()`);
                    fillfiles("workers job done");
                }
            }
        });
        fillfiles("main");
    }
    else {
        //worker
        process.on('message', (msg) => {
            if(msg.cmd == "EAT"){
                logger.info('[WORKER] ' + cluster.worker.id +' command: ' + msg.cmd + ", file_id " + msg.file_id);
                processor(cluster.worker.id, msg.files);
            }
            else if(msg.cmd == "SLEEP"){
                logger.info('[WORKER] ' + cluster.worker.id +' command: ' + msg.cmd );
                process.send({event: "SLEEPING"});
            }
            else if(msg.cmd == "WAKEUP"){
                logger.info('[WORKER] ' + cluster.worker.id +' command: ' + msg.cmd );
                process.send({event: "READY"});
            }
        });

        process.send({event: "READY"});
        logger.info(`[WORKER] ${cluster.worker.id} process ${process.pid} is running`);
        //processor function
        async function processor(wrkr_id, files) {
            for (const file of files) {
                await setstate(file.file_id, "STARTING");
            }
            try {
                const result = await processorext(wrkr_id, files);
                for (const file of result) {
                    if(file.body){
                        await setstate(file.file_id, "FINISHED", file.body);
                    }
                    else{
                        await setstate(file.file_id, "FINISHED");
                    }
                }
            }
            catch(e) {
                for (const file of files) {
                    await setstate(file.file_id, "ERROR");
                }
            }
            process.send({event: "READY"});
        }
    }

});
