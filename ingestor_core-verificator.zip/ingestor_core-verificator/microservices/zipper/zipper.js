const path = require('path');
const logger = require('../../utils/Logger.js');
const config = require('../../utils/Configuration.js');
const axios = require('axios');
const fs = require('fs'); 
const archiver = require('archiver');

exports.performTask = async function (wrkr_id, file_id) {

    return new Promise(async (resolve, reject) => {
        try {
			const folder_base = config.instance().getObject().folder_base;
			const folder_in_file = folder_base + '/' + config.instance().gettenant_id() + '/zipper/';
			const wav_file = folder_in_file + file_id + '.wav';
			const json_file = folder_in_file + file_id + '.json';

			var folder_base_out = folder_base;
			if(config.instance().getObject().microservices.zipper.folder_base_out != undefined) {
				folder_base_out = config.instance().getObject().microservices.zipper.folder_base_out;
			}
			const error_file = folder_base_out + '/' + config.instance().gettenant_id() + '/zipper/error/'+ file_id + '.wav';
			const folder_out_file = folder_base_out + '/' + config.instance().gettenant_id() + '/uploader/';
			const zip_file = folder_out_file + file_id + '.zip';

            fs.accessSync(wav_file);
            logger.info('[ZIPPER] '+ wrkr_id +' FIle found: ' + wav_file);

            await getAndCreateMetadataJson(wrkr_id, config.instance().gettenant_id(), file_id, json_file);
            await archiverZipFiles(wrkr_id, json_file, wav_file, zip_file);

            fs.rmSync(wav_file, {throwIfNoEntry: false});
            fs.rmSync(json_file, {throwIfNoEntry: false});

            resolve();
        }
        catch(e) {
            logger.error('[ZIPPER] '+ wrkr_id +' Error ' + e);
            fs.mkdirSync(path.dirname(error_file), {recursive: true});
            fs.rename(wav_file, error_file, () => {});
            reject(e);
        }
        
    });
}


async function getAndCreateMetadataJson(wrkr_id, tenantId, audioID, json){
    try{
        if(!tenantId||!audioID || !json){
            throw new Error(`Parametros de ingreso invalidos`);
        }
        const queryData=JSON.stringify({
            "tenant_id": tenantId,
            "file_id": audioID
          });

        const config_ = {
            method: 'get',
            maxBodyLength: Infinity,
            url: config.instance().getapilayer_url() + '/ingestor/v1/metadata',
            headers: { 
              'Content-Type': 'application/json'
            },
            data : queryData
          };

        const getMetadataResponse = await axios.request(config_);
        
        if(getMetadataResponse.status !== 200   ){
            throw new Error(getMetadataResponse.data)
        }

        const responseData=getMetadataResponse.data;
        
        const metadataJson = JSON.parse(responseData.metadata);
        
        if(!metadataJson){
            throw new Error(`Json metadata invalido`)
        }
        
        const jsonStringiFy = JSON.stringify(metadataJson,null,4);
        
        fs.writeFileSync(json, jsonStringiFy,'utf8');
        logger.info(`[INGESTOR-ZIPPER] ${wrkr_id}[Worker-getAndCreateMetadataJson(INFO)]: JSON METADATA OBTENIDO Y CREADO CORRECTAMENTE `)
        return true;

    } catch(e){
        logger.error(`[INGESTOR-ZIPPER] ${wrkr_id}[Worker-getAndCreateMetadataJson(ERROR)]: No se lograron obtener los datos ${e}`)
        throw(e)
    }
}

async function archiverZipFiles(wrkr_id, json, wav, out){
    try{
        if(!json||! wav||!out){
            throw new Error(`Faltan parametros `);
        }

        fs.mkdirSync(path.dirname(out), {recursive: true});

        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(out);
            const archive = archiver('zip', {
                zlib: { level: 9 } // Configurar la compresión al máximo nivel
            });

            output.on('close', () => {
                logger.info(`[INGESTOR-ZIPPER] ${wrkr_id} Archivo ZIP creado con éxito: ${archive.pointer()} bytes`);
                resolve(out);
            });

            archive.on('error', (err) => {
                reject(err);
            });

            archive.pipe(output);
            archive.file(json, { name: path.basename(json) });
            archive.file(wav, { name: path.basename(wav) });
            archive.finalize();

            logger.info(`[INGESTOR-ZIPPER] ${wrkr_id}[WORKER-archiverZipFiles(INFO)]: Archivos zippeados correctamente`);
            return true;
        });
      
    }catch(e){
        logger.error(`[INGESTOR-ZIPPER] ${wrkr_id}[WORKER-archiverZipFiles(ERROR)]: No se logro completar el proceso ${e}`);
        throw(e);
    }
}




