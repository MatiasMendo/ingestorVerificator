const fs = require('fs');
const AdmZip = require('adm-zip');
const path = require('path');
const AWS = require("aws-sdk");
const logger = require('../../../utils/Logger.js');

let s3

exports.upload = async function (file_id, localFilePath, credentials) {
    if(!s3) {
        if(!credentials.access_key_id && !credentials.secret_access_key){
            AWS.config.update({
                accessKeyId : credentials.access_key_id,
                secretAccessKey : credentials.secret_access_key,
                region : credentials.region
            })
        } else {
            AWS.config.update({
                region : credentials.region
            })
        }
        s3 = new AWS.S3();
    }
    try {
        fs.accessSync(localFilePath);
        logger.info('[UPLOADER] File found: ' + localFilePath);

        const fileBuffer = fs.readFileSync(localFilePath);

        // Verificar el estado del archivo
        const zip = new AdmZip(fileBuffer);
        const zipEntities = zip.getEntries();
        if (zipEntities.length < 1) {
            throw new Error('[UPLOADER] El archivo está corrupto')
        }

        const remoteFilePath = credentials.bucket_folder + "/" + file_id + ".zip"
        // Subir el archivo
        const params = {
            Bucket: credentials.bucket,
            Key: remoteFilePath,
            Body: fileBuffer,
        };
        const uploadResult = await s3.upload(params).promise();
        logger.info('[UPLOADER]: Archivo '+ localFilePath +' subido con éxito: ' + `${remoteFilePath} :` + uploadResult.Location);

        // Eliminar archivo local
        fs.rmSync(localFilePath, {throwIfNoEntry: false});

        // Verificar que el archivo se subió correctamente
        const headParams = {
            Bucket: credentials.bucket,
            Key: remoteFilePath,
        };
        await s3.headObject(headParams).promise();
        logger.info('[WorkerUpload]: Verificación exitosa. El archivo existe en S3.');
    } catch(e) {
        logger.error('[UPLOADER]: Desconectando del S3')
        s3 = undefined
        throw new Error(e)
    }
}
