const logger = require('../../../utils/Logger.js');
const Client = require('ssh2-sftp-client');
const fs = require('fs'); 

let sftp

async function connectToSftp(credentials) {
    logger.info('[UPLOADER][connectToSftp]: Conectando al Sftp')

    logger.info('Connection config')

    const host= credentials.host
    const user= credentials.user
    const port= credentials.port
    let conectionOptions;
    if (credentials.pass){
        conectionOptions={
            host: host,
            port: parseInt(port),
            username: user,
            password: credentials.pass,
            algorithms: {
                    kex: ['diffie-hellman-group1-sha1', 'diffie-hellman-group14-sha1'],
                    serverHostKey: ['ssh-rsa']
                }
        };
    } else if(credentials.privateKey){
        const privateKey = fs.readFileSync(credentials.privateKey)
        conectionOptions={
            host: host,
            port: parseInt(port),
            username: user,
            privateKey: privateKey,
            algorithms: {
                    kex: ['diffie-hellman-group1-sha1', 'diffie-hellman-group14-sha1'],
                    serverHostKey: ['ssh-rsa']
                }
        };
    } else {
        throw new Error("[UPLOADER] Credenciales incorrectos")
    }
    logger.info(conectionOptions)
    const sftp = new Client()
    await sftp.connect(conectionOptions)
    logger.info('[UPLOADER][connectToSftp]: Conexión Sftp establecida con éxito')   
    return sftp
}

exports.upload = async function (file_id, localFilePath, credentials) {
    if(!sftp){
        sftp = await connectToSftp(credentials)
    }
    try {
        fs.accessSync(localFilePath);
        logger.info('[UPLOADER] File found: ' + localFilePath);

        const fileBuffer = fs.readFileSync(localFilePath);
        // Verificar el estado del archivo
        const zip = new AdmZip(fileBuffer);
        const zipEntities = zip.getEntries();
        if (zipEntities.length < 1) { 
            throw new Error('[UPLOADER] El archivo está corrupto')
        }

        const remoteFilePath = credentials.sftp_folder + file_id + ".zip"

        // Subir el archivo
        await sftp.put(localFilePath, remoteFilePath)
        logger.info('[UPLOADER]: Archivo '+ localFilePath +' subido con éxito');

        // Eliminar archivo local
        fs.rmSync(localFilePath, {throwIfNoEntry: false});
    } catch (e) {
        await sftp.end()
        logger.error('[UPLOADER][connectToSftp]: Desconectando del Sftp')   
        sftp = undefined
        throw new Error(e)
    }
}