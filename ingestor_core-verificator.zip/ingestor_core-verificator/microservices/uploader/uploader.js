const logger = require('../../utils/Logger.js');
const config = require('../../utils/Configuration.js');
const fs = require('fs');
const path = require('path');

function getUploader(uploaderType) {
    if(uploaderType == "sftp") {
        return require("./modules/sftp-uploader.js");
    } else if(uploaderType == "s3"){
        return require("./modules/s3-uploader.js");
    }
    else {
        throw new Error("[INPUT][] Starting microservice error uploader type not found")
    }
}


exports.performTask = async function (wrkr_id, file_id) {
    const folder_base = config.instance().getObject().folder_base;
    const input_folder = folder_base + '/' + config.instance().gettenant_id() + '/uploader/';
    const error_file = folder_base + '/' + config.instance().gettenant_id() + '/uploader/error/'+ file_id + '.zip';
    const zip_file = input_folder + file_id + '.zip';

    return new Promise(async (resolve, reject) => {

        try {
            const uploaderType = config.instance().getObject().microservices.uploader.type;
            const uploader = getUploader(uploaderType)

            await uploader.upload(file_id, zip_file, config.instance().getObject().microservices.uploader.credentials)

            resolve();
        }
        catch(e) {
            logger.error('[UPLOADER] Error ' + e);
            fs.mkdirSync(path.dirname(error_file), {recursive: true});
            fs.rename(zip_file, error_file, () => {});
            reject();
        }
    });
}
