const platformClient = require('purecloud-platform-client-v2')
const logger = require('../../../utils/Logger.js');

let client
let recordingApi

async function connectToPurecloud(credentials) {
    logger.info(credentials)
    client = platformClient.ApiClient.instance
    const environment = platformClient.PureCloudRegionHosts[credentials.region]
    client.setEnvironment(environment)
    client.setPersistSettings(true)
    const { accessToken } = await client.loginClientCredentialsGrant(credentials.client_id, credentials.client_secret)
    client.setAccessToken(accessToken)

    logger.info("[connectToPurecloud] Se logra conectar a PureCloud")

    recordingApi = new platformClient.RecordingApi();
}


exports.verify = async function (wrkr_id, files, credentials) {
    await connectToPurecloud(credentials)
    const batchRequestBody = {
        batchDownloadRequestList : files.map(file =>
            ({
                "conversationId": file.customdata.conversationId,
                "recordingId": file.customdata.recordingId
            })
        )
    }
    logger.info(batchRequestBody)
    const result = await recordingApi.postRecordingBatchrequests(batchRequestBody)

    const batchRequestId = result.id
    let recordingStatus
    do {
        await new Promise(resolve => setTimeout(resolve, 6000))
        recordingStatus = await recordingApi.getRecordingBatchrequest(batchRequestId)
        logger.info(`[VERIFICATOR] ${wrkr_id} [progress]:  ${recordingStatus.results.length}/${recordingStatus.expectedResultCount}`)
    } while (recordingStatus.expectedResultCount !== recordingStatus.results.length);

    const verificator_results = []
    logger.info(recordingStatus)
    for (const r of recordingStatus.results) {
        const file = files.find(file => file.customdata.conversationId === r.conversationId && file.customdata.recordingId === r.recordingId);
        verificator_results.push({
            "file_id" : file.file_id,
            "body" : {
                "source" : r.resultUrl
            }
        })
    }

    return verificator_results
}

// 1) Almacenar en una lista los recordings ID

// 2) Hacer un batch request al GC

// 3) Ver el status de ese batch

// 4) Obtener los links de descarga

// 5) Postear al API Layer / cambiar source al http
