const config = require('../../utils/Configuration.js');
const logger = require('../../utils/Logger.js');

function getVerificator(verificatorType) {
    if (verificatorType == "genesys-cloud"){
        return require("./modules/genesys-cloud.js")
    } else {
        throw new Error("[VERIFICATOR][] Starting microservice error verificator type not found")
    }
}

exports.performTask = async function (wrkr_id, files) {
    return new Promise(async (resolve, reject) => {
        try {
            const verificatorType = config.instance().getObject().microservices.verificator.type;
            const verificator = getVerificator(verificatorType)
            logger.info('[VERIFICATOR] '+ wrkr_id +' Comienza la verificación de: '+ files.length)
            const credentials = config.instance().getObject().microservices.verificator.credentials
            const result = await verificator.verify(wrkr_id, files, credentials)
            logger.info('[VERIFICATOR] '+ wrkr_id +' Se completo la verificación de: '+ files.length)
            resolve(result)
        } catch (error) {
            logger.error('[VERIFICATOR] '+ wrkr_id +' Error ' + JSON.stringify(error));
            reject(error)
        }
    })
}
