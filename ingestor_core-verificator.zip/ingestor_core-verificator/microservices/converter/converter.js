const logger = require('../../utils/Logger.js');
const config = require('../../utils/Configuration.js');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const os= require('os');

const extensions = ['wav', 'WAV', 'mp3', 'MP3', 'ogg', 'OGG'];


exports.performTask = async function (wrkr_id, file_id) {
    return new Promise(async (resolve, reject) => {

        const folder_base = config.instance().getObject().folder_base;
        const folder_in_file = folder_base + '/' + config.instance().gettenant_id() + '/converter/';
        const error_folder = folder_base + '/' + config.instance().gettenant_id() + '/converter/error/';
        const folder_out_file = folder_base + '/' + config.instance().gettenant_id() + '/zipper/';
        const wav_in_filename = folder_in_file + file_id;
        var _in_file = null;
        var _in_extension = null;
        const wav_out_file = folder_out_file + file_id + '.wav';

        try {


            for(let idx=0; idx < extensions.length; idx++) {
                try {
                    fs.accessSync(wav_in_filename + '.' + extensions[idx]);
                    _in_extension = extensions[idx]
                    _in_file = wav_in_filename + '.' + _in_extension;
                    break;
                }
                catch(e) {
                }
            };

            if(_in_file == null) {
                logger.error('[CONVERTER] File not found with file_id '+ file_id +', or extension not found');
                throw('File not found Unsupported extension')
            }

            logger.info('[CONVERTER] File found: ' + _in_file);
	    if(os.type() === 'Linux') {
		    await convertirAudio(_in_file, wav_out_file);
	    }
	    else { //asume windows
		    await convertirAudio(path.win32.normalize(_in_file), path.win32.normalize(wav_out_file));
	    }
            logger.info(`[CONVERTER]-[performTask(INFO)]: Se completo el proceso de manera exitosa `);
            fs.rmSync(_in_file, {throwIfNoEntry: false});

            resolve();

        }
        catch(e) {
            logger.error('[CONVERTER] Error ' + e);
            if(_in_file != null) {
               fs.mkdirSync(error_folder, {recursive: true});
               fs.rename(_in_file, error_folder + file_id + '.' + _in_extension, () => {});
            }

            reject(e);
        }
    });
}

async function convertirAudio(inputLocal, rutaLocal) {
    // Esta función usa una promesa internamente para manejar el comportamiento asincrónico
    fs.mkdirSync(path.dirname(rutaLocal), {recursive: true});
    return new Promise((resolve, reject) => {
        ffmpeg()
            .input(inputLocal)
            .audioCodec('pcm_s16le')
            .audioFrequency(8000)
            // .audioChannels(1) // NO SÉ SI DEBERIA CAMBIARLO JAJA
            .audioBitrate('128k')
            .outputOptions("-sample_fmt s16")
            .on('end', () => {
                //console.log('Conversión completada con éxito.');
                // fs.unlinkSync(inputLocal); // DESCOMENTAR AL ARREGLAR DESCARGA
                resolve();
            }).on('error', (err) => {
                console.error('Error durante la conversión:', err);
                reject(err);
            }).save(rutaLocal);
    });
}
