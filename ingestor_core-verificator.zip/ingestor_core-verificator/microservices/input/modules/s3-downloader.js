const AWS = require('aws-sdk')
const fs = require('fs').promises;
const logger = require('../../../utils/Logger.js');

let s3

exports.download = async function (remoteFilePath, localFilePath, credentials) {
    
    if(!s3) {
        if(!credentials.access_key_id && !credentials.secret_access_key){
            AWS.config.update({
                accessKeyId : credentials.access_key_id,
                secretAccessKey : credentials.secret_access_key,
                region : credentials.region
            })
        } else {
            AWS.config.update({
                region : credentials.region
            })
        }
        s3 = new AWS.S3();
    }
    try {
        const params = {
            Bucket : credentials.bucket,
            Key : remoteFilePath
        }
        const data = await s3.getObject(params).promise()
        await fs.writeFile(localFilePath, data.Body)
    } catch(e) {
        logger.error('[DOWNLOADER]: Desconectando del S3')   
        s3 = undefined
        throw new Error(e)
    }
}
