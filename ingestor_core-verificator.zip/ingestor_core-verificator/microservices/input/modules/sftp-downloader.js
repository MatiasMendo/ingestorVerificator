const logger = require('../../../utils/Logger.js');
const Client = require('ssh2-sftp-client');

let sftp

async function connectToSftp(credentials) {
    logger.info('[DOWNLOADER][connectToSftp]: Conectando al Sftp')

    const host= credentials.host
    const user= credentials.user
    const pass= credentials.pass
    const port= credentials.port

    const conectionOptions={
        host: host,
        port: parseInt(port),
        username: user,
        password: pass,
        algorithms: {
                kex: ['diffie-hellman-group1-sha1', 'diffie-hellman-group14-sha1'],
                serverHostKey: ['ssh-rsa']
            }
    };
    const sftp = new Client()
    await sftp.connect(conectionOptions)
    logger.info('[DOWNLOADER][connectToSftp]: Conexión Sftp establecida con éxito')   
    return sftp
}

exports.download = async function (remoteFilePath, localFilePath, credentials) {
   if(!sftp){
        sftp = await connectToSftp(credentials)
    }
    try {
        await sftp.get(remoteFilePath, localFilePath)
    } catch(e) {
        await sftp.end()
        logger.error('[DOWNLOADER][connectToSftp]: Desconectando del Sftp')   
        sftp = undefined
        throw new Error(e)
    }
}
