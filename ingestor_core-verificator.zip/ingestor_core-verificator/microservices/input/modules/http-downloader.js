const http = require('node:https')
const logger = require('../../../utils/Logger.js');
const fs = require('fs')

exports.download = async function (remoteFilePath, localFilePath, credentials) {
    try {
        const file = fs.createWriteStream(localFilePath)

        await new Promise((resolve, reject) =>
            http.get(remoteFilePath, function (response) {
              response.pipe(file)
              file.on('finish', async function () {
                file.close()
                logger.info(`[downloadRecording] :: Recording ${localFilePath} downloaded successfully`)
                resolve()
              })
            }).on('error', async function (err) {
              logger.warn(`[downloadRecording] :: error downloading ${localFilePath}`)
              logger.error(err)
              fs.unlinkSync(localFilePath)
              reject(err)
            })
          )
    } catch(e) {
        throw new Error(e)
    }
}
