const config = require('../../utils/Configuration.js');
const logger = require('../../utils/Logger.js');
const fs = require('fs');

function getDownloader(downloaderType) {
    if(downloaderType == "sftp") {
        return require("./modules/sftp-downloader.js");
    } else if(downloaderType == "s3"){
        return require("./modules/s3-downloader.js");
    } else if(downloaderType == "http"){
        return require("./modules/http-downloader.js");
    }
    else {
        throw new Error(`[INPUT][] Starting microservice error input type ${downloaderType} not found`)
    }
}

function getExtension(file){
    const supportedExtensions = ["mp3", "ogg", "wav"]
    const lastDotIndex = file.lastIndexOf('.');
    const extension = lastDotIndex !== -1 ? file.slice(lastDotIndex + 1) : '';

    if(supportedExtensions.includes(extension)){
        return extension
    }
    return "ogg"
}

exports.performTask = async function (wrkr_id, file_id, file_obj) {
    return new Promise(async (resolve, reject) => {
	    try {
            const downloaderType = config.instance().getObject().microservices.input.type;
            let downloader = getDownloader(downloaderType)

		    const folder_base = config.instance().getObject().folder_base;
        	const folder_out_file = folder_base + '/' + config.instance().gettenant_id() + '/converter/';
        	const ext = getExtension(file_obj.source)
            if(!fs.existsSync(folder_out_file)){
                fs.mkdirSync(folder_out_file,{recursive:true});
            }
            logger.info('[INPUT] '+ wrkr_id +' Comienza la descarga de: '+ file_obj.source)
            const credentials = config.instance().getObject().microservices.input.credentials

            await downloader.download(file_obj.source, folder_out_file + `${file_id}.${ext}`,credentials)

            logger.info('[INPUT] '+ wrkr_id +' Se completo la descarga de: '+file_obj.source + ` con nombre ${file_id}.${ext}`)
            resolve()
        } catch(e) {
            logger.error('[INPUT] '+ wrkr_id +' Error ' + e);
            reject(e)
        }
    })
}
